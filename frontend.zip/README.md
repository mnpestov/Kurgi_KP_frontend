---
permalink: /index.html
---
Это приложение для создания коммерческого предложения с последующей выгрузкой в pdf
https://mnpestov.github.io/kurgi_kp/